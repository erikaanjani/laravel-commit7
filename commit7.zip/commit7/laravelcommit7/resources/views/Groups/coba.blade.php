@extends('layouts.app')

@section('title', 'cobaaaa')
@section('content')
urutan ke - {{ $ke }}
@endsection 